<?php

namespace Mpdf\Tag;

class Div extends BlockTag
{


}
