<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Printdata extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->helper(array('form', 'url', 'date', 'global'));
	}

	public function index()
	{
		$data['list'] = [
			'Laporan Kejadian' => [
				'view' => 'laporan-kejadian'
			],
			'Surat perintah penyidikan' => [
				'view' => 'surat-perintah-penyidikan'
			],
			'Surat pemberitahuan dimulainya penyidikkan' => [
				'view' => 'surat-pemberitahuan-dimulainya-penyidikan'
			],
			'Surat pemanggilan saksi' => [
				'view' => 'surat-pemanggilan-saksi'
			],
			'Berita acara pemeriksaan saksi' => [
				'view' => 'berita-acara-pemeriksaan-saksi'
			],
			'Berita acara pengambilan sumpah saksi' => [
				'view' => 'berita-acara-pengambilan-sumpah-saksi'
			],
			'Berita acara pemeriksaan ahli' => [
				'view' => 'berita-acara-pemeriksaan-ahli'
			],
			'Nota dinas penunjukan saksi ahli' => [
				'view' => 'nota-dinas-penunjukan-saksi-ahli'
			],
			'Surat perintah tugas' => [
				'view' => 'surat-perintah-tugas'
			],
			'Surat perintah penangkapan' => [
				'view' => 'surat-perintah-penangkapan'
			],
			'Berita acara penangkapan' => [
				'view' => 'berita-acara-penangkapan'
			],
			'Berita acara penggeledahan' => [
				'view' => 'berita-acara-penggeledahan'
			],
			'Surat perintah penggeledahan' => [
				'view' => 'surat-perintah-penggeledahan'
			],
			'Berita acara penyitaan' => [
				'view' => 'berita-acara-penyitaan'
			],
			'Surat perintah penyitaan' => [
				'view' => 'surat-perintah-penyitaan'
			],
			'Daftar saksi' => [
				'view' => 'daftar-saksi'
			],
			'Daftar tersangka' => [
				'view' => 'daftar-tersangka'
			],
			'Daftar barang bukti' => [
				'view' => 'daftar-barang-bukti'
			]
		];
		$this->load->view('form/list', $data);
	}

	public function cetak()
	{

		date_default_timezone_set('Asia/Jakarta');
		$data['title'] = 'P 21';
		$data['data'] = $this->input->post();
		// echo '<pre>';
		// echo json_encode($data);
		// die;
		$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => ['210', '330']]);
		$mpdf->SetDefaultFont('Arial');
		$mpdf->SetMargins(15, 15, 15, 15);

		$html = $this->load->view('pdf/laporan-kejadian', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/surat-perintah-penyidikan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/spdp', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/surat-panggilan-saksi', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/bap-pengambilan-sumpah-saksi', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/nodin-saksi-ahli', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/bap-tersangka', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/sprint-penangkapan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/ba-penangkapan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/berita-acara-penggeledahan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/surat-penggeledahan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/ba-penyitaan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/surat-tanda-penerimaan', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->AddPage();
		$html = $this->load->view('pdf/surat-daftar-saksi', $data, true);
		$mpdf->WriteHTML($html);

		$mpdf->Output('contoh.pdf', 'I');
	}
}

/* End of file PrintData.php */